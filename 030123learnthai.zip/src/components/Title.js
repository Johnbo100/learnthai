import React from 'react'

function Title() {
  return (
    <div className='title'>English <span className='yeltitle'>to</span> <span id="thai">Thai</span> <span className='yeltitle'>Flash Cards</span></div>
  )
}

export default Title